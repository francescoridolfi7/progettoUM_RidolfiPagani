using progettoUMRidolfiPagani.Models;

namespace progettoUMRidolfiPagani.Services.Interface
{
    public interface IStoricoService
    {
        Task<IEnumerable<Movimento>> GetMovimentiByArticoloIdAsync(int articoloId);
        Task<IEnumerable<Movimento>> GetMovimentiByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<TimeSpan> CalcolaTempoPermanenzaAsync(int articoloId);
        Task<double> CalcolaMediaGiorniPermanenzaAsync();
        Task<IEnumerable<Articolo>> GetArticoliPiuVecchiAsync(int count);
        Task<IEnumerable<Movimento>> GetMovimentiRecentiAsync(int days);
        Task<IEnumerable<Movimento>> GetStoricoCompletoAsync();
        Task<IEnumerable<Movimento>> GetStoricoByArticoloIdAsync(int articoloId);
        Task<Movimento> GetMovimentoDettagliByIdAsync(int movimentoId);

    }
}

